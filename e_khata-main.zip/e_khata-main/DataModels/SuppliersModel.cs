﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class SuppliersModel
    {
        public int supplierid { get; set; }
        public string? name { get; set; }
        public string? contact_supp { get; set; }
        public string? citytype { get; set; }
    }
}
