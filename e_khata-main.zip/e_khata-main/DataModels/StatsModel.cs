﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class StatsModel
    {
        public int totalordercomplete { get; set; }
        public int totalorderstaken { get; set; }
        public int totalsales { get; set; }
    }
}
