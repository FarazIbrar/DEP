﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class SessionDataModel
    {
        public string? Name { get; set; }
    }
}
