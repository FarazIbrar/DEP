﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class SessionModel
    {
        public string? name { get; set; }
        public bool cataddcheck {get; set; }
        public string checklogin { get; set; }
    }
}
