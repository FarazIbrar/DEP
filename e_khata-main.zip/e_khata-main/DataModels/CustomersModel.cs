﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModels
{
    public class CustomersModel
    {
        public int customerid { get; set; }
        public string? name { get; set; }
        public string? contact { get; set; }
    }
}
