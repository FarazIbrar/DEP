| Date        | Version | Description |
| ----------- | ------- | ----------- |
| 2020-05-13  | v2.0.1  | Revert bower.json deletion but not use it in CI build |
| 2020-05-11  | v2.0.0  | Migrate to github actions, upgrade minimal node version and remove bower |
| 2019-02-08  | v1.0.32 | Maintenance |
| 2018-06-25  | v1.0.28 | Expose webNotification.requestPermission #5 |
| 2018-06-14  | v1.0.26 | Better error detection on chrome mobile #4 |
| 2017-08-25  | v1.0.21 | Support service worker web notifications |
| 2017-01-31  | v1.0.3  | Removed polyfill dependency |
| 2017-01-22  | v1.0.0  | Official release |
| 2017-01-22  | v0.0.2  | Initial release |
