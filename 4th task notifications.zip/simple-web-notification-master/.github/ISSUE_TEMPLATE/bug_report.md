---
name: Bug Report
about: Create a report to help us improve
title: ''
labels: ''
assignees: sagiegurari

---

### Describe The Bug
<!-- A clear and concise description of what the bug is. -->

### To Reproduce
<!-- Steps to reproduce the behavior: -->

### Error Stack

```console
The error stack trace
```

### Code Sample

```js
// paste code here
```
