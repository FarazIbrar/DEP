---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: sagiegurari

---

### Feature Description
<!-- A clear description of the feature request. -->

### Describe The Solution You'd Like
<!-- A clear and concise description of what you want to happen. -->

### Code Sample

```js
// paste code here
```
